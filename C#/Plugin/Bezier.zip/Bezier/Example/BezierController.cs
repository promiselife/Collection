﻿/**
 * Author: Sander Homan
 * Copyright 2012
 **/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

class BezierController : MonoBehaviour
{
    public AnimationCurve speedCurve;
    public BezierPath path = null;
    public bool byDist = false;

    public float t = 0;
    public float timer = 0;

    void Start()
    {
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            t = 0;
            timer = 0;
        }
        if (timer > 25)
        {
            t = 0;
            timer = 0;
        }
        t += speedCurve.Evaluate(timer) * Time.deltaTime;
        timer += Time.deltaTime;

        Vector3 pos;
        Vector3 dir;
        if (!byDist)
        {
            pos = path.GetPositionByT(t);
            dir = path.GetDriectionByT(t);
        }
        else
        {
            pos = path.GetPositionByDistance(t);
            dir = path.GetDirectionByDistance(t);
        }
        transform.position = pos;
        transform.rotation = Quaternion.LookRotation(new Vector3(dir.x, 0, dir.z));
    }
}

